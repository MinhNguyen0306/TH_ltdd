package com.example.KTCK_Lan3_THLTDD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KtckLan3ThltddApplicationTests {

	@Test
	void contextLoads() {
	}

}
