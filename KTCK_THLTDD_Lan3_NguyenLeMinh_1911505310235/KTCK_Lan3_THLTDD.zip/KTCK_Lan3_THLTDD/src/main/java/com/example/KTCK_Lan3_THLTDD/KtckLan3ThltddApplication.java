package com.example.KTCK_Lan3_THLTDD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KtckLan3ThltddApplication {

	public static void main(String[] args) {
		SpringApplication.run(KtckLan3ThltddApplication.class, args);
	}

}
